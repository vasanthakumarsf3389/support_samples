## Available Scripts

In the project directory, first you can run DataAPI directory:

### `npm start`

Open [http://localhost:3007/orderdetails](http://localhost:3007/orderdetails)

Refer the following documentation to configure the JSON server
[Configure-JSON-server](https://github.com/typicode/json-server)
