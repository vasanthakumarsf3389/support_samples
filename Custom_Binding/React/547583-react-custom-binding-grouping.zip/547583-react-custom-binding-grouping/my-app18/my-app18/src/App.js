// memory leak

import { GridComponent, ColumnsDirective, ColumnDirective, Inject, VirtualScroll, Grid, RowDD, Toolbar, Group, Edit, Page, Filter, Sort, ColumnChooser, Search, Print, Reorder, Resize, ContextMenu, CommandColumn, InfiniteScroll } from '@syncfusion/ej2-react-grids';
import { templateCompiler } from '@syncfusion/ej2-grids';
import { ButtonComponent } from '@syncfusion/ej2-react-buttons';
import * as React from 'react';
import { useEffect, useRef, useState, useMemo } from 'react';
import { Route, Routes, Link, BrowserRouter } from 'react-router-dom';
import { data, datasource, virtualData } from './data';
import { Ajax, getValue } from '@syncfusion/ej2-base';

let lazyLoadData = [];
var customerid = ['VINET', 'TOMSP', 'HANAR', 'VICTE', 'SUPRD', 'HANAR', 'CHOPS', 'RICSU', 'WELLI', 'HILAA', 'ERNSH', 'CENTC',
  'OTTIK', 'QUEDE', 'RATTC', 'ERNSH', 'FOLKO', 'BLONP', 'WARTH', 'FRANK', 'GROSR', 'WHITC', 'WARTH', 'SPLIR', 'RATTC', 'QUICK', 'VINET',
  'HUNGO', 'PRINI', 'FRANK', 'OLDWO', 'MEREP', 'BONAP', 'SIMOB', 'FRANK', 'LEHMS', 'WHITC', 'QUICK', 'RATTC', 'FAMIA'];
var product = ['Chai', 'Chang', 'Aniseed Syrup', 'Chef Anton\'s Cajun Seasoning', 'Chef Anton\'s Gumbo Mix', 'Grandma\'s Boysenberry Spread',
  'Gudbrandsdalsost', 'Outback Lager', 'Flotemysost', 'Mozzarella di Giovanni', 'Röd Kaviar', 'Longlife Tofu', 'Rhönbräu Klosterbier', 'Lakkalikööri', 'Original Frankfurter grüne Soße'];
var customername = ['Maria', 'Ana Trujillo', 'Antonio Moreno', 'Thomas Hardy', 'Christina Berglund', 'Hanna Moos', 'Frédérique Citeaux', 'Martín Sommer', 'Laurence Lebihan', 'Elizabeth Lincoln',
  'Victoria Ashworth', 'Patricio Simpson', 'Francisco Chang', 'Yang Wang', 'Pedro Afonso', 'Elizabeth Brown', 'Sven Ottlieb', 'Janine Labrune', 'Ann Devon', 'Roland Mendel', 'Aria Cruz', 'Diego Roel',
  'Anabela Domingues', 'Helvetius Nagy', 'Palle Ibsen', 'Mary Saveley', 'Paul Henriot', 'Rita Müller', 'Pirkko Koskitalo', 'Paula Parente', 'Karl Jablonski', 'Matti Karttunen', 'Zbyszek Piestrzeniewicz'];
var customeraddress = ['507 - 20th Ave. E.\r\nApt. 2A', '908 W. Capital Way', '722 Moss Bay Blvd.', '4110 Old Redmond Rd.', '14 Garrett Hill', 'Coventry House\r\nMiner Rd.', 'Edgeham Hollow\r\nWinchester Way',
  '4726 - 11th Ave. N.E.', '7 Houndstooth Rd.', '59 rue de l\'Abbaye', 'Luisenstr. 48', '908 W. Capital Way', '722 Moss Bay Blvd.', '4110 Old Redmond Rd.', '14 Garrett Hill', 'Coventry House\r\nMiner Rd.', 'Edgeham Hollow\r\nWinchester Way',
  '7 Houndstooth Rd.', '2817 Milton Dr.', 'Kirchgasse 6', 'Sierras de Granada 9993', 'Mehrheimerstr. 369', 'Rua da Panificadora, 12', '2817 Milton Dr.', 'Mehrheimerstr. 369'];
var quantityperunit = ['10 boxes x 20 bags', '24 - 12 oz bottles', '12 - 550 ml bottles', '48 - 6 oz jars', '36 boxes', '12 - 8 oz jars', '12 - 1 lb pkgs.', '12 - 12 oz jars', '18 - 500 g pkgs.', '12 - 200 ml jars',
  '1 kg pkg.', '10 - 500 g pkgs.', '2 kg box', '40 - 100 g pkgs.', '24 - 250 ml bottles', '32 - 500 g boxes', '20 - 1 kg tins', '16 kg pkg.', '10 boxes x 12 pieces', '30 gift boxes', '24 pkgs. x 4 pieces', '24 - 500 g pkgs.', '12 - 250 g pkgs.',
  '12 - 355 ml cans', '20 - 450 g glasses', '100 - 250 g bags'];

var OrderID = 10248;

for (var i = 0; i < 20000; i++) {
  lazyLoadData.push({
      'OrderID': OrderID + i,
      'CustomerID': customerid[Math.floor(Math.random() * customerid.length)],
      'CustomerName': customername[Math.floor(Math.random() * customername.length)],
      'CustomerAddress': customeraddress[Math.floor(Math.random() * customeraddress.length)],
      'ProductName': product[Math.floor(Math.random() * product.length)],
      'ProductID': i,
      'Quantity': quantityperunit[Math.floor(Math.random() * quantityperunit.length)]
  });
}

export class OrderService {
  ajax = new Ajax({
    mode: true,
    onFailure: (e) => false,
    type: 'GET',
  });
  BASE_URL = "https://services.odata.org/V4/Northwind/Northwind.svc/Orders/"

  execute(state) {
    return this.getData(state);
  }

  getData(state) {
    const skip = state.skip !== undefined ? '$skip=' + state.skip : undefined;
    const take = state.take ? '$top=' + state.take : undefined;
    const pageQuery = skip && take ? skip + '&' + take : undefined;
    // const groupQuery = state.sorted ? '$orderby='+ state.sorted : undefined;
    let sortQuery = '';
    if ((state.sorted || []).length) {
      sortQuery =
        `$orderby=` +
        state.sorted
          .map((obj) => {
            return obj.direction === 'descending'
              ? `${obj.name} desc`
              : obj.name;
          })
          .reverse()
          .join(',');
    }
    const filterQuery = state.filter ? `` : undefined;
    this.ajax.url = `${this.BASE_URL}?${state.requiresCounts ? '$count=true&' : ''}${filterQuery ? filterQuery + '&' : ''}${sortQuery ? sortQuery + '&' : ''}${pageQuery ? pageQuery : ''}`;


    return this.ajax.send().then((response) => {
      const data = JSON.parse(response);
      if (data['@odata.count']) {
        return {
          count: parseInt( data['@odata.count'], 10),
          result: getValue('value', data),
        };
      } else {
        return {
          result: getValue('value', data),
        };
      }
    });
  }
}

//539098-persistence-with-templlate
// eslint-disable-next-line
import SharedGrid from './Grid';
const App = (props) => {
  let gridInstance;
  // let isInitialLoad;
  let data;
  // let data = new DataManager({
  //   url: "https://services.odata.org/V4/Northwind/Northwind.svc/Orders/",
  //   adaptor: new ODataV4Adaptor()
  // });
  const orderService = new OrderService();

  const dataBound = () => {
    console.log('databounded!');
    if (
      gridInstance &&
      gridInstance.dataSource instanceof Array &&
      !gridInstance.dataSource.length
    ) {
      const state = {
        action: { requestType: 'infiniteScroll' },
        skip: 0,
        group: [],
        groups: [],
        sorted: [],
        take: gridInstance.pageSettings.pageSize * 3, // for infinite scroll
        // take: gridInstance.pageSettings.pageSize, // for paging
        requiresCounts: true,
      };
      let groupSettings = gridInstance.groupSettings;
      if (groupSettings.columns.length) {
        groupSettings.columns.forEach((column) => {
          state.groups.push(column);
          state.sorted.push({ name: column, direction: 'ascending' });
        });
        state.group.push(
          groupSettings.columns[groupSettings.columns.length - 1]
        );
      }
      dataStateChange(state);
    }
  };

  const dataStateChange = (state) => {
    // if (
    //   state.action &&
    //   (state.action.requestType === 'infiniteScroll' ||
    //     state.action.requestType === 'grouping' ||
    //     state.action.requestType === 'ungrouping' ||
    //     !Object.keys(state.action).length)
    // ) {
    // if (Object.keys(state.action).length) {
      orderService.execute(state).then((gridData) => {
        if (gridInstance) {
          // if (!Object.keys(state.action).length) {
          //   gridInstance.dataBind();
          //   return;
          // }
          // gridInstance.setProperties({dataSource: gridData}, false);
          gridInstance.dataSource = gridData;
          // if (!isInitialLoad && gridInstance.groupSettings.columns.length) {
          //   console.log(isInitialLoad ? true : false);
          //   // gridInstance.refresh();
          //   isInitialLoad = true;
          // } else if (
          //   !isInitialLoad &&
          //   !gridInstance.groupSettings.columns.length
          // ) {
          //   console.log(isInitialLoad ? true : false);
          //   isInitialLoad = true;
          // }
        }
      });
    // }
  };
  const toolbarOptions = ['ColumnChooser'];
  return (
    <div className="control-pane">
      <br />
      <br />
      <br />
      <br />
      <div className="control-section">
        <GridComponent
          id="Grid"
          dataSource={data}
          ref={(grid) => (gridInstance = grid)}
          enableInfiniteScrolling={true}
          // infiniteScrollSettings={{initialBlocks: 3, maxBlocks: 3}}
          height={400}
          // allowPaging={true}
          pageSettings={{ pageSize: 12 }}
          dataBound={dataBound}
          dataStateChange={dataStateChange}
          allowGrouping={true}
          allowReordering={true}
          showColumnChooser={true}
          
          toolbar={toolbarOptions}
          groupSettings={{
            columns: ['CustomerID', 'ShipCountry'], showGroupedColumn: true
            // disablePageWiseAggregates: true
          }}
        >
          <ColumnsDirective>
            <ColumnDirective
              field="OrderID"
              headerText="Order ID"
              width="120"
              textAlign="Right"
            ></ColumnDirective>
            <ColumnDirective
              field="CustomerID"
              headerText="Customer ID"
              width="160"
            ></ColumnDirective>
            <ColumnDirective
              field="EmployeeID"
              headerText="Employee ID"
              width="120"
              textAlign="Right"
            />
            <ColumnDirective
              field="ShipCountry"
              headerText="Ship Country"
              width="150"
            ></ColumnDirective>
          </ColumnsDirective>
          <Inject services={[InfiniteScroll, Group, Page, Toolbar, ColumnChooser, Reorder]} />
        </GridComponent>
      </div>
    </div>
  );
  };
  
  export default App;