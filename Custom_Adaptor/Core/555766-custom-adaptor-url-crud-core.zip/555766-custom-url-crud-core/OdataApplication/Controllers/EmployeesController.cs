﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using OdataApplication.Models;

namespace OdataApplication.Controllers
{
    [Route("odata/[controller]")]
    [ApiController]
    public class EmployeesController : ODataController
    {
        [EnableQueryWithMetadata]
        public IActionResult Get()
        {
            return Ok(Employees.ForeignData().AsQueryable());
        }
    }
}
