﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OdataApplication.Models;
using Syncfusion.EJ2.Base;
using System.Collections;
using System.Diagnostics;
using System.Dynamic;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace OdataApplication.Controllers
{
    public class HomeController : Controller
    {
        public static List<OrdersDetails> orddata = OrdersDetails.GetAllRecords();
        public static List<EmployeeDetails> empdata = new List<EmployeeDetails>();
        public string device_info = string.Empty;

        public class Browser
        {
            public string userAgent { get; set; }
            public Regex OS { get; set; }
            public Regex device { get; set; }
        }
        public IActionResult Index()
        {
            var browserinfo = new Browser()
            {
                userAgent = Request.Headers["User-Agent"].ToString(),
                OS = new Regex(@"(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino", RegexOptions.IgnoreCase | RegexOptions.Multiline),
                device = new Regex(@"1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-", RegexOptions.IgnoreCase | RegexOptions.Multiline)
            };
            if (browserinfo.OS.IsMatch(browserinfo.userAgent))
            {
                device_info = browserinfo.OS.Match(browserinfo.userAgent).Groups[0].Value;
            }
            if (browserinfo.device.IsMatch(browserinfo.userAgent.Substring(0, 4)))
            {
                device_info += browserinfo.device.Match(browserinfo.userAgent).Groups[0].Value;
            }
            if (!string.IsNullOrEmpty(device_info))
            {
                ViewBag.enablePersistence = false;
                ViewBag.DeviceInfo = "You are using a Mobile device. " + device_info;
            }
            else
            {
                ViewBag.enablePersistence = true;
                ViewBag.DeviceInfo = "You are using a Desktop device.";
            }
            ViewBag.datasource = OrdersDetails.GetAllRecords().Skip(2).Take(10);
            ViewBag.datasource1 = OrdersDetails.GetAllRecords().Take(2);
            return View();
        }

        public IActionResult RowDropped([FromBody] CRUDModel value)
        {
            return View();
        }

        public IActionResult UrlDatasource([FromBody] DataManagerRequest dm)
        {

            IEnumerable DataSource = orddata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        public IActionResult Update([FromBody] CRUDModel<OrdersDetails> myObject)
        {
            var ord = myObject;
            OrdersDetails val = orddata.Where(or => or.OrderID == ord.Value.OrderID).FirstOrDefault();
            if (val != null)
            {
                val.OrderID = ord.Value.OrderID;
                val.EmployeeID = ord.Value.EmployeeID;
                val.CustomerID = ord.Value.CustomerID;
                val.Freight = ord.Value.Freight;
                val.OrderDate = ord.Value.OrderDate;
                val.ShipCity = ord.Value.ShipCity;
                val.ShipAddress = ord.Value.ShipAddress;
                val.ShippedDate = ord.Value.ShippedDate;
            }

            return Json(ord.Value);

        }
        public IActionResult Insert([FromBody] CRUDModel<OrdersDetails> value)
        {
            var ord = value;
            orddata.Insert(0, ord.Value);
            return Json(value.Value);
        }
        public IActionResult Delete([FromBody] CRUDModel<OrdersDetails> value)
        {
            int key;
            if (int.TryParse(value.Key.ToString(), out key))
            {
                orddata.Remove(orddata.Where(or => or.OrderID == key).FirstOrDefault());
            }
            return Json(value);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult TestFetch()
        {
            return View();
        }

    }
}