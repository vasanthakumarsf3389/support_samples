﻿using Microsoft.AspNetCore.Mvc;

namespace OdataApplication.Controllers
{
    public class TabController : Controller
    {
        public IActionResult Tab()
        {
            //ViewBag.tradeData = TradeDetails.GetAllRecords();
            return View();
        }
    }
}
