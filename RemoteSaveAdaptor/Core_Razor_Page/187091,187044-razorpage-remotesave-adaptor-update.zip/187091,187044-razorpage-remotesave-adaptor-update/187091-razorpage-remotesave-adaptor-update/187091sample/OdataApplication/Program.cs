using Microsoft.AspNetCore.OData;
using Microsoft.OData.Edm;
using Microsoft.OData.ModelBuilder;
using Microsoft.EntityFrameworkCore;
using OdataApplication;
using OdataApplication.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRazorPages();
// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddCors(
        options => options.AddPolicy("AllowCors",
        builder =>
        {
            builder
            //.WithHeaders("Accept", "Content-type", "Origin", "X-Custom-Header");  //AllowSpecificHeaders;
            .AllowAnyHeader(); //AllowAllHeaders;
        })
    );

//builder.Services.AddControllers().AddOData(options => options.EnableQueryFeatures());

//builder.Services.AddDbContext<EfDbContext>(options =>
//{
//    //options.UseSqlServer("Data Source=localhost;Initial Catalog=Northwind;Integrated Security=True");
//    options.UseSqlServer(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + Directory.GetCurrentDirectory() + @"\Models\NORTHWND.MDF;Integrated Security=True");
//});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

//app.UseODataRouteDebug();
app.MapRazorPages();

app.MapControllerRoute(
    name: "default",
pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
