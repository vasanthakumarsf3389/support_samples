﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;
using OdataApplication.Models;
using Syncfusion.EJ2.Base;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace OdataApplication.Controllers
{
    public class HomeController : Controller
    {
        public static List<OrdersDetails> orddata = OrdersDetails.GetAllRecords();
        public static List<OrdersDetails> orddata1 = OrdersDetails.GetAllRecords().Take(2).ToList();
        public IActionResult Index()
        {
            ViewBag.datasource = orddata;
            ViewBag.datasource1 = OrdersDetails.GetAllRecords().Take(2);
            return View();
        }

        public IActionResult Index1()
        {
            ViewBag.datasource = orddata;
            ViewBag.datasource1 = OrdersDetails.GetAllRecords().Take(2);
            return View();
        }

        public IActionResult UrlDatasource([FromBody] DataManagerRequest dm)
        {

            IEnumerable DataSource = orddata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        public IActionResult Update([FromBody] CRUDModel<OrdersDetails> myObject)
        {
            var ord = myObject;
            OrdersDetails val = orddata.Where(or => or.OrderID == ord.Value.OrderID).FirstOrDefault();
            if (val != null)
            {
                val.OrderID = ord.Value.OrderID;
                val.EmployeeID = ord.Value.EmployeeID;
                val.CustomerID = ord.Value.CustomerID;
                val.Freight = ord.Value.Freight;
                val.OrderDate = ord.Value.OrderDate;
                val.ShipCity = ord.Value.ShipCity;
                val.ShipAddress = ord.Value.ShipAddress;
                val.ShippedDate = ord.Value.ShippedDate;
            }

            return Json(ord.Value);

        }
        public IActionResult Insert([FromBody] CRUDModel<OrdersDetails> value)
        {
            var ord = value;
            orddata.Insert(0, ord.Value);
            return Json(value.Value);
        }
        public IActionResult Delete([FromBody] CRUDModel<OrdersDetails> value)
        {
            int key;
            if (int.TryParse(value.Key.ToString(), out key))
            {
                orddata.Remove(orddata.Where(or => or.OrderID == key).FirstOrDefault());
            }
            return Json(value);
        }

        public IActionResult RemoteSaveUpdate([FromBody] CRUDModel<OrdersDetails> value)
        {
            if(value.Action == "update")
            {
                var ord = value;
                OrdersDetails val = orddata.Where(or => or.OrderID == ord.Value.OrderID).FirstOrDefault();
                if (val != null)
                {
                    val.OrderID = ord.Value.OrderID;
                    val.EmployeeID = ord.Value.EmployeeID;
                    val.CustomerID = ord.Value.CustomerID;
                    val.Freight = ord.Value.Freight;
                    val.OrderDate = ord.Value.OrderDate;
                    val.ShipCity = ord.Value.ShipCity;
                    val.ShipAddress = ord.Value.ShipAddress;
                    val.ShippedDate = ord.Value.ShippedDate;
                    val.Verified = ord.Value.Verified;
                }
            }
            else if (value.Action == "insert")
            {
                var ord = value;
                orddata.Insert(0, ord.Value);
                return Json(value.Value);
            }
            else if (value.Action == "remove")
            {
                int key;
                if (int.TryParse(value.Key.ToString(), out key))
                {
                    orddata.Remove(orddata.Where(or => or.OrderID == key).FirstOrDefault());
                }
                return Json(value);
            }
            return Json(value);
        }

        public class RowDrop
        {
            public RowDrop()
            {

            }

            [Key]
            [JsonProperty("data")]
            public List<OrdersDetails> data { get; set; }
            [JsonProperty("dropIndex")]
            public int dropIndex { get; set; }
        }

        public IActionResult RowDropped([FromBody] RowDrop value)
        {
            //update db here
            for (int i = 0; i < value.data.Count; i++)
            {
                orddata.Remove(orddata.Where(or => or.OrderID == value.data[i].OrderID).FirstOrDefault());
                orddata.Insert(value.dropIndex, value.data[i]);
            }
            return Json(new { data1 = orddata });
        }

        //public class RowDrop
        //{
        //    public RowDrop()
        //    {

        //    }

        //    [Key]
        //    [JsonProperty("lineId")]
        //    public int LineId { get; set; }
        //    [JsonProperty("oldIndex")]
        //    public int OldIndex { get; set; }
        //    [JsonProperty("newIndex")]
        //    public int NewIndex { get; set; }
        //}

        //public IActionResult RowDropped([FromBody] object moveposition)
        //{
        //    var yourObject = JsonConvert.DeserializeObject<RowDrop>(moveposition.ToString());
        //    //index is zero based, order field is not
        //    byte oldLineOrder = Convert.ToByte(yourObject.OldIndex + 1);
        //    byte newLineOrder = Convert.ToByte(yourObject.NewIndex + 1);
        //    //if oldIndex > newIndex, went up order
        //    //everything between oldIndex and NewIndex goes down
        //    if (oldLineOrder > newLineOrder)
        //    {
        //        List<OrdersDetails> lstLines = new List<OrdersDetails>();
        //        lstLines = orddata.Where(o => o.OrderID >= newLineOrder
        //                                                && o.OrderID < oldLineOrder).ToList();
        //        foreach (OrdersDetails line in lstLines)
        //        {
        //            line.OrderID = Convert.ToByte(line.OrderID + 1);
        //            orddata.Attach(line);
        //        }
        //        OrdersDetails ogl = orddata.FirstOrDefault(o => o.OrderID == yourObject.LineId);
        //        if (ogl != null)
        //        {
        //            ogl.OrderID = newLineOrder;
        //            orddata.Attach(ogl);
        //        }
        //    }
        //    else if (oldLineOrder < newLineOrder)
        //    {
        //        //if oldIndex < newIndex, went down order
        //        //everything between oldIndex and NewIndex goes up
        //        List<OffensiveGameplanLine> lstLines = new List<OffensiveGameplanLine>();
        //        lstLines = _ctx.OffensiveGameplanLines.Where(o => o.OffensiveGameplanLineOrder > oldLineOrder
        //                                                && o.OffensiveGameplanLineOrder <= newLineOrder).ToList();
        //        foreach (OffensiveGameplanLine line in lstLines)
        //        {
        //            line.OffensiveGameplanLineOrder = Convert.ToByte(line.OffensiveGameplanLineOrder - 1);
        //            _ctx.OffensiveGameplanLines.Attach(line);
        //        }
        //        OffensiveGameplanLine ogl = await _ctx.OffensiveGameplanLines
        //                                .FirstOrDefaultAsync(o => o.OffensiveGameplanLineId == yourObject.LineId);
        //        if (ogl != null)
        //        {
        //            ogl.OffensiveGameplanLineOrder = newLineOrder;
        //            _ctx.OffensiveGameplanLines.Attach(ogl);
        //        }
        //    }
        //    await _ctx.SaveChangesAsync();
        //    return Json(moveposition);
        //}


        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult TestFetch()
        {
            return View();
        }

    }
}