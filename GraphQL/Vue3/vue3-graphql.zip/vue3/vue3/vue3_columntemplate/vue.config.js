module.exports = {
    runtimeCompiler: true
      }