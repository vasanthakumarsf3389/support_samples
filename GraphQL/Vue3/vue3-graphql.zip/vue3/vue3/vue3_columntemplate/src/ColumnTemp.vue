/* eslint-disable */ 
<template>
  <div> {{data.OrderID}} - {{data.CustomerID}}
  <button @click="viewCollection(data.OrderID)" class="btn btn-sm btn-primary"> <i class="bi bi-eye-fill"></i> View</button>
  </div>
</template>
<script>
export default {
  name: "dialogTemplate1",
  data() {
    return {
    };
  },
  methods:{
    viewCollection: function(args){
      debugger;
      console.log(args);
    }
  }
};
</script>