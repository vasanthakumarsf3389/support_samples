/* eslint-disable */ 
<!-- <template>
  <div id="app">
    <ejs-grid :dataSource='data' :allowPaging="true" >
      <e-columns>
          <e-column field='CustomerID' width='125' textAlign='Right'></e-column>
          <e-column field='OrderID' width='125' textAlign='Right'></e-column>
          <e-column field='ShipCountry' width='125' textAlign='Right'></e-column>
          <e-column headerText='Employee Image' width='150' textAlign='Center' ></e-column>
      </e-columns>
  </ejs-grid>
    </div>
</template>

<script>
import { GridComponent, ColumnsDirective, ColumnDirective, Page } from '@syncfusion/ej2-vue-grids';
// import dialogTemplate1 from "./ColumnTemp.vue";

// import { createApp } from "vue";
// const app = createApp();
// // Template declaration
// var colVue = app.component("colTemplate", dialogTemplate1);


export default {
  name: 'App',
  components: {
    'ejs-grid' : GridComponent,
'e-columns' : ColumnsDirective,
'e-column' : ColumnDirective,
  },
  data() {
return {
  data:  [
    {
       "OrderID":10248,
       "CustomerID":"VINET",
       "ShipCountry":"France"
    },
    {
       "OrderID":10249,
       "CustomerID":"TOMSP",
       "ShipCountry":"Germany"
    },
    {
       "OrderID":10250,
       "CustomerID":"HANAR",
       "ShipCountry":"Brazil"
    }],
    // colTemplate: function () {
    //     return { template: colVue};
    //   },
};
  },
  // module injection
  provide: {
grid: [Page],
  }
};
</script> -->


<!-- <template>
  <div class="col-lg-12 control-section">
          <div class="control-section">
          <ejs-grid ref="grid" :dataSource="data" :allowGrouping='true' :allowPaging='true' :allowSorting='true' :groupSettings='groupOptions' :editSettings='editSettings' :toolbar='toolbar' :pageSettings='pageOptions' :created='created' height=320>
              <e-columns>
                  <e-column field='OrderID' headerText='Order ID' width='120' textAlign='Right' :isPrimaryKey='true' :validationRules='orderidrules'></e-column>
                  <e-column field='CustomerID' headerText='Customer ID' width='120' :validationRules='customeridrules'></e-column>
                  <e-column field='Freight' headerText='Freight' width='180' format='C2' textAlign='Right' editType='numericedit' :validationRules='freightrules'></e-column>
                  <e-column field='OrderDate' headerText='Order Date' width='130' editType='datetimepickeredit' :allowGrouping='false' :format='formatoptions' textAlign='Right'></e-column>
                  <e-column field='ShipCountry' headerText='Ship Country' width='150' editType='dropdownedit' :edit='editparams'></e-column>
              </e-columns>
          </ejs-grid>
          </div>
           <ejs-dialog :buttons='alertDlgButtons' ref="alertDialog" v-bind:visible="false" :header='alertHeader' :animationSettings='animationSettings' :content='alertContent' :showCloseIcon='showCloseIcon' :target='target'
              :width='alertWidth'>
          </ejs-dialog>
          <div style="margin-top: 10px; text-align: right">Source:
              <a href="https://en.wikipedia.org/wiki/List_of_prolific_inventors" target='_blank'>Wikipedia: List of Prolific inventors</a>
          </div>
  
  
  </div>
  </template> -->
  <!-- <style>
    col.e-group-intent {
        width: 20.5px !important;
    }
  </style> -->
  <!-- <script>
  import { GridComponent, ColumnDirective, ColumnsDirective, Group, Page, Sort, Edit, Toolbar } from "@syncfusion/ej2-vue-grids";
  // import { orderDataSource } from "./data-source";
  import { DialogComponent } from '@syncfusion/ej2-vue-popups';
  
  export default {
    components: {
      'ejs-grid': GridComponent,
      'e-column': ColumnDirective,
      'e-columns': ColumnsDirective,
      'ejs-dialog': DialogComponent
    },
    data: function() {
      return {
        alertHeader: 'Grouping',
        alertContent: 'Grouping is disabled for this column',
        showCloseIcon: false,
        target: '.control-section',  
        alertWidth: '300px',
        animationSettings: { effect: 'None' },
        alertDlgButtons: [{ click: ((this).alertDlgBtnClick), buttonModel: { content: 'OK', isPrimary: true } }],
        

        data: (window).orderDataSource,
        editSettings: { allowEditing: true },
        toolbar: ['Edit', 'Update', 'Cancel'],
        orderidrules: { required: true, number: true },
        customeridrules: { required: true },
        formatoptions: { type: 'dateTime', format: 'M/d/y hh:mm a' },
        freightrules:  { required: true },
        editparams: { params: { popupHeight: '300px' }},
        pageOptions: { pageCount: 5 },
        groupOptions: { columns: ["ShipCountry"] }
      };
    },
    methods: {
      created: function() {
          ((this).$refs.grid.ej2Instances).on("columnDragStart", this.columnDragStart, this);
      },
      columnDragStart: function(args) {
          if(args.column.field === "OrderDate"){
               ((this).$refs.alertDialog).show();
          }
      },
      alertDlgBtnClick: function() {
          ((this).$refs.alertDialog).hide();
      },
    },
    provide: {
      grid: [Group, Page, Sort, Edit, Toolbar]
    }
  }
  </script>
  <style>
  @import "../node_modules/@syncfusion/ej2-base/styles/material3.css";
  @import "../node_modules/@syncfusion/ej2-buttons/styles/material3.css";
  @import "../node_modules/@syncfusion/ej2-calendars/styles/material3.css";
  @import "../node_modules/@syncfusion/ej2-dropdowns/styles/material3.css";
  @import "../node_modules/@syncfusion/ej2-inputs/styles/material3.css";
  @import "../node_modules/@syncfusion/ej2-navigations/styles/material3.css";
  @import "../node_modules/@syncfusion/ej2-popups/styles/material3.css";
  @import "../node_modules/@syncfusion/ej2-splitbuttons/styles/material3.css";
  @import "../node_modules/@syncfusion/ej2-vue-grids/styles/material3.css";
</style> -->



<!-- GraphQLAdaptor -->

<template>
  <div style="margin:0 auto;">
    <h3 style="text-align: CENTER;">Syncfusion Vue Grid</h3>
    <ejs-grid :dataSource="data" height='210px' :query="query" :allowPaging="true">
      <e-columns>
        <e-column field='OrderID' headerText='OrderID' width='150' textAlign='Right'></e-column>
        <e-column field='CustomerID' headerText='Customer Name' width='150'></e-column>
        <e-column field='ShipCountry' headerText='Ship Country' width='150'></e-column>
      </e-columns>
      <e-aggregates>
        <e-aggregate>
          <e-a-columns>
            <e-a-column type="Sum" field="OrderID" :footerTemplate='footerSum'></e-a-column>
          </e-a-columns>
        </e-aggregate>
        <e-aggregate>
          <e-a-columns>
            <e-a-column type="Max" field="OrderID" :footerTemplate='footerMax'></e-a-column>
          </e-a-columns>
        </e-aggregate>
      </e-aggregates>
    </ejs-grid>
  </div>
</template>

<script>
import { GridComponent, ColumnsDirective, ColumnDirective,
  AggregatesDirective,
  AggregateDirective,
  AggregateColumnDirective,
  AggregateColumnsDirective,
  Grid, Aggregate } from "@syncfusion/ej2-vue-grids";
import { createApp } from "vue";
import { DataManager, Query, GraphQLAdaptor } from '@syncfusion/ej2-data';

let SERVICE_URI =
  "http://localhost:4200/";

Grid.Inject(Aggregate);
const app = createApp();
var footerSum = app.component('footerSum', {
  template: `Sum: {{data.Sum}}`,
  data() { return { data: {} }; }
});

var footerMax = app.component('footerMax', {
  template: `Max: {{data.Max}}`,
  data() { return { data: {} }; }
});


export default {
  name: "grid",
  components: {
    'ejs-grid': GridComponent,
    'e-aggregates': AggregatesDirective,
    'e-aggregate': AggregateDirective,
    'e-columns': ColumnsDirective,
    'e-column': ColumnDirective,
    'e-a-columns': AggregateColumnsDirective,
    'e-a-column': AggregateColumnDirective
  },
  data() {
    return {
      footerSum: function () {
        return { template: footerSum };
      },
      footerMax: function () {
        return { template: footerMax };
      }
    };
  },
  computed: {
    
    data: function () { 
      let data = new DataManager({
        url: SERVICE_URI,
        adaptor: new GraphQLAdaptor({
          response: {
            count: 'getOrders.count',
            result: 'getOrders.result'
          },
          getMutation: function (action) {
            if (action === 'insert') {
              return `mutation Create($value: OrderInput!){
                                        createOrder(value: $value){
                                            OrderID, CustomerID, EmployeeID, ShipCountry
                                    }}`;
            }
            if (action === 'update') {
              return `mutation Update($key: Int!, $keyColumn: String,$value: OrderInput){
                            updateOrder(key: $key, keyColumn: $keyColumn, value: $value) {
                                OrderID, CustomerID, EmployeeID, ShipCountry
                            }
                            }`;
            } else {
              return `mutation Remove($key: Int!, $keyColumn: String, $value: OrderInput){
                    deleteOrder(key: $key, keyColumn: $keyColumn, value: $value) {
                                OrderID, CustomerID, EmployeeID, ShipCountry
                            }
                            }`;
            }
          },
          query: `query getOrders($datamanager: DataManager) {
                    getOrders(datamanager: $datamanager) {
                      count,
                      result{OrderID, CustomerID, EmployeeID, ShipCountry}
                  }
          }`,
        })
      })
      return data;
      },
    query: function () {
      let query = new Query().addParams('ej2grid', 'true').addParams('first', '30').addParams('sortingBy', 'userCreatedOn');
      return query;
    }
  },
    provide: {
      grid: [Aggregate]
    }
};
</script >

<style>
@import '../node_modules/@syncfusion/ej2-base/styles/bootstrap.css';
@import '../node_modules/@syncfusion/ej2-buttons/styles/bootstrap.css';
@import '../node_modules/@syncfusion/ej2-grids/styles/bootstrap.css';
@import '../node_modules/@syncfusion/ej2-dropdowns/styles/bootstrap.css';
@import '../node_modules/@syncfusion/ej2-inputs/styles/bootstrap.css';
@import '../node_modules/@syncfusion/ej2-navigations/styles/bootstrap.css';
@import '../node_modules/@syncfusion/ej2-popups/styles/bootstrap.css';
@import '../node_modules/@syncfusion/ej2-calendars/styles/bootstrap.css';
@import '../node_modules/@syncfusion/ej2-splitbuttons/styles/bootstrap.css';

.form-group.col-md-6 {
  width: 250px;
  height: 54px;
}

.form-group.col-md-12 {
  height: 72px;
}

#ShipAddress {
  resize: vertical;
}
</style>
