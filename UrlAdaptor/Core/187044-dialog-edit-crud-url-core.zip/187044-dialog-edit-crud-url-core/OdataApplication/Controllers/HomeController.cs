﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;
using OdataApplication.Models;
using Syncfusion.EJ2.Base;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace OdataApplication.Controllers
{
    public class HomeController : Controller
    {
        public static List<OrdersDetails> orddata = OrdersDetails.GetAllRecords();
        public static List<OrdersDetails> orddata1 = OrdersDetails.GetAllRecords().Take(2).ToList();
        public IActionResult Index()
        {
            ViewBag.datasource = orddata;
            ViewBag.datasource1 = OrdersDetails.GetAllRecords().Take(2);
            return View();
        }

        public IActionResult UrlDatasource([FromBody] DataManagerRequest dm) // requested by datamanager url adaptor url.
        {

            IEnumerable DataSource = orddata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take); //Paging
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        public IActionResult Update([FromBody] CRUDModel<OrdersDetails> myObject) // requested by datamanager url adaptor update url.
        {
            var ord = myObject;
            OrdersDetails val = orddata.Where(or => or.OrderID == ord.Value.OrderID).FirstOrDefault(); // getting primary key matching data.
            if (val != null)
            {
                val.OrderID = ord.Value.OrderID;
                val.EmployeeID = ord.Value.EmployeeID;
                val.CustomerID = ord.Value.CustomerID;
                val.Freight = ord.Value.Freight;
                val.OrderDate = ord.Value.OrderDate;
                val.ShipCity = ord.Value.ShipCity;
                val.ShipAddress = ord.Value.ShipAddress;
                val.ShippedDate = ord.Value.ShippedDate;
                val.ShipCountry = ord.Value.ShipCountry;
                val.Verified = ord.Value.Verified;
            }

            return Json(ord.Value);

        }
        public IActionResult Insert([FromBody] CRUDModel<OrdersDetails> value) // requested by datamanager url adaptor insert url.
        {
            var ord = value;
            orddata.Insert(0, ord.Value); // Insert Record
            return Json(value.Value);
        }
        public IActionResult Delete([FromBody] CRUDModel<OrdersDetails> value) // requested by datamanager url adaptor remove url.
        {
            int key;
            if (int.TryParse(value.Key.ToString(), out key))
            {
                orddata.Remove(orddata.Where(or => or.OrderID == key).FirstOrDefault()); // Delete record by matching primary key value.
            }
            return Json(value);
        }



        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult TestFetch()
        {
            return View();
        }

    }
}