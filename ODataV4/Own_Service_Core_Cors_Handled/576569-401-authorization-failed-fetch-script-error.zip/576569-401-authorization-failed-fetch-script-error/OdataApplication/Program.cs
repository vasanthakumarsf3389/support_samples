using Microsoft.AspNetCore.OData;
using Microsoft.OData.Edm;
using Microsoft.OData.ModelBuilder;
using Microsoft.EntityFrameworkCore;
using OdataApplication;
using OdataApplication.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using OdataApplication.Controllers;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;


//old odata technique for count query handling purpose
//static IEdmModel GetEdmModel()
//{
//    ODataConventionModelBuilder builder = new ODataConventionModelBuilder();
//    builder.EntitySet<OrdersDetails>("Orders");
//    builder.EntitySet<Employees>("Employees");
//    return builder.GetEdmModel();
//}
var builder = WebApplication.CreateBuilder(args);
var modelBuilder = new ODataConventionModelBuilder();
// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddControllers().AddOData(
    options => options.Select().Filter().OrderBy().Expand().Count().SetMaxTop(OrdersDetails.GetAllRecords().Count)
    //old odata technique for count query handling purpose
    //.AddRouteComponents("odata", GetEdmModel())
    .AddRouteComponents(
        routePrefix: "odata",
        model: modelBuilder.GetEdmModel())
    .EnableQueryFeatures());

//builder.Services.AddCors(
//        options => options.AddPolicy("AllowCors",
//        builder =>
//        {
//            builder.AllowAnyOrigin()
//            //.WithHeaders("Accept", "Content-type", "Origin", "X-Custom-Header");  //AllowSpecificHeaders;
//            .AllowAnyHeader(); //AllowAllHeaders;
//        })
//    );

// Configure JWT authentication
var key = Encoding.ASCII.GetBytes("JwtSettings:Secret");
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ValidateIssuer = false,
        ValidateAudience = false
    };
});

var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: MyAllowSpecificOrigins,
                      policy =>
                      {
                          policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
                          //policy.WithOrigins("http://localhost:4200/",
                          //"http://www.contoso.com", "https://react-yn9uz5.stackblitz.io", "https://react-wpv1yv.stackblitz.io", "http://localhost:3000/").AllowAnyHeader().AllowAnyMethod().AllowCredentials();
                      });
});
builder.Services.AddMvc()
            .AddJsonOptions(options =>
            {
                // Custom JSON format for interop with an old system that uses PascalCase
                // and enums as numbers
                options.JsonSerializerOptions.PropertyNamingPolicy = null;
            });


//builder.Services.AddDbContext<EfDbContext>(options =>
//{
//    //options.UseSqlServer("Data Source=localhost;Initial Catalog=Northwind;Integrated Security=True");
//    options.UseSqlServer(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + Directory.GetCurrentDirectory() + @"\Models\NORTHWND.MDF;Integrated Security=True");
//});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();
app.UseAuthentication();

//app.UseODataRouteDebug();

app.UseCors(MyAllowSpecificOrigins);

app.MapControllerRoute(
    name: "default",
pattern: "{controller=Home}/{action=Index}/{id?}");
//pattern: "{controller=Tab}/{action=Tab}/{id?}");
//pattern: "{controller=Home}/{action=TestFetch}/{id?}");
//pattern: "{controller=Url}/{action=Index}/{id?}");
//pattern: "{controller=Overview}/{action=Index}/{id?}");

app.Run();
