﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using OdataApplication.Models;

namespace OdataApplication.Controllers
{
    //if use old odata technique for count query handling purpose must be command below route and api
    [Route("odata/[controller]")]
    [ApiController]
    public class EmployeesController : ODataController
    {
        [EnableQueryWithMetadata]
        //[EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult Get()
        {
            return Ok(Employees.ForeignData().AsQueryable());
        }
    }
}
