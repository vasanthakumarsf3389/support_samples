﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using OdataApplication.Models;

namespace OdataApplication.Controllers
{
    //if use old odata technique for count query handling purpose must be command below route and api
    [Route("odata/[controller]")]
    [ApiController]
    //[Authorize]
    public class OrdersController : ODataController
    {

        [EnableQueryWithMetadata]
        //old odata technique for count query handling purpose
        //[EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult Get()
        {
            //// Check if user is authenticated
            //if (!User.Identity.IsAuthenticated)
            //{
            //    // If not authenticated, return 401 Unauthorized
            //    HttpContext.Response.StatusCode = 401;
            //    return new JsonResult("Unauthorized access");
            //}

            return Ok(OrdersDetails.GetAllRecords().AsQueryable());
        }
    }
}
