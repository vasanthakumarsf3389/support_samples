﻿using Microsoft.AspNetCore.Mvc;
using OdataApplication.Models;
using Syncfusion.EJ2.Base;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace OdataApplication.Controllers
{
    public class UrlController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        [Route("Grid/UrlDataSource")]

        public IActionResult UrlDatasource([FromBody] DataManagerRequest dm)
        {
            long count;

            //Queryable
            //IQueryable<OrdersDetails> DataSource = OrdersDetails.GetAllRecords().AsQueryable();
            IQueryable<dynamic> DataSource = OrdersDetails.GetAllRecords().AsQueryable();
            QueryableOperation operation = new QueryableOperation();

            // Enumerable

            //IEnumerable<OrdersDetails> DataSource = OrdersDetails.GetAllRecords().AsEnumerable();
            //DataOperations operation = new DataOperations();


            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource.Cast<OrdersDetails>(), dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource.Cast<OrdersDetails>(), dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource.Cast<OrdersDetails>(), dm.Where, dm.Where[0].Operator);
            }
            if (dm.Select != null && DataSource.Cast<dynamic>().Count() != 0)
            {
                IQueryable Data = operation.PerformSelect(DataSource.Cast<dynamic>(), dm.Select);  // Selected the columns value based on the filter request 
                DataSource = Data.Cast<dynamic>().Distinct().AsQueryable(); // Get the distinct values from the selected column 
            }
            count = DataSource.Cast<dynamic>().Count();
            if (dm.Skip != 0)
            {
                if (dm.Select != null)
                {
                    DataSource = operation.PerformSkip(DataSource.Cast<dynamic>(), dm.Skip);//Paging
                }
                else
                {
                    DataSource = operation.PerformSkip(DataSource.Cast<OrdersDetails>(), dm.Skip);   //Paging
                }
            }
            if (dm.Take != 0)
            {
                if (dm.Select != null)
                {
                    DataSource = operation.PerformTake(DataSource.Cast<dynamic>(), dm.Take);
                }
                else
                {
                    DataSource = operation.PerformTake(DataSource.Cast<OrdersDetails>(), dm.Take);
                }
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        [Route("Grid/FUrlDataSource")]
        public ActionResult FUrlDataSource([FromBody] DataManagerRequest dm)
        {
            long count = 0;
            //Queryable

            //IQueryable<Employees> DataSource = Employees.ForeignData().AsQueryable();
            //IQueryable<dynamic> DataSource = Employees.ForeignData().AsQueryable();
            IQueryable<dynamic> DataSource = EmployeeView.GetAllRecords().AsQueryable();
            var operation = new QueryableOperation();

            // Enumerable

            //IEnumerable<Employees> DataSource = Employees.ForeignData().AsEnumerable();
            //DataOperations operation = new DataOperations();

            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource.Cast<EmployeeView>(), dm.Where, dm.Where[0].Operator);
            }
            if (dm.Search != null && dm.Search.Count > 0)  //Search
            {
                DataSource = operation.PerformSearching(DataSource.Cast<EmployeeView>(), dm.Search);
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource.Cast<EmployeeView>(), dm.Sorted);
            }

            //if (dm.RequiresCounts)
            //{
            //    count = DataSource.Cast<OrdersDetails>().Count();
            //}

            if (dm.Select != null && DataSource.Cast<dynamic>().Count() != 0)
            {
                IQueryable Data = operation.PerformSelect(DataSource.Cast<dynamic>(), dm.Select);  // Selected the columns value based on the filter request 
                DataSource = Data.Cast<dynamic>().Distinct().AsQueryable(); // Get the distinct values from the selected column 
            }
            count = DataSource.Cast<dynamic>().Count();

            if (dm.Skip != 0)
            {
                if (dm.Select != null)
                {
                    DataSource = operation.PerformSkip(DataSource.Cast<dynamic>(), dm.Skip);//Paging
                }
                else
                {
                    DataSource = operation.PerformSkip(DataSource.Cast<EmployeeView>(), dm.Skip);//Paging
                }
            }
            if (dm.Take != 0)
            {
                if (dm.Select != null)
                {
                    DataSource = operation.PerformTake(DataSource.Cast<dynamic>(), dm.Take);
                }
                else
                {
                    DataSource = operation.PerformTake(DataSource.Cast<EmployeeView>(), dm.Take);
                }
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }
    }
}
