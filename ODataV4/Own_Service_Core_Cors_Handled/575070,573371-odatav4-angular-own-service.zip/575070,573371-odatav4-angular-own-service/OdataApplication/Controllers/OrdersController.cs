﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using OdataApplication.Models;

namespace OdataApplication.Controllers
{
    //if use old odata technique for count query handling purpose must be command below route and api
    [Route("odata/[controller]")]
    [ApiController]
    public class OrdersController : ODataController
    {
        [EnableQueryWithMetadata]
        //old odata technique for count query handling purpose
        //[EnableQuery(AllowedQueryOptions = AllowedQueryOptions.All)]
        public IActionResult Get()
        {
            return Ok(OrdersDetails.GetAllRecords().AsQueryable());
        }
    }
}
