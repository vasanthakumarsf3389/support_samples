﻿using Microsoft.AspNetCore.Mvc;
using Syncfusion.EJ2.Base;
using System.ComponentModel.DataAnnotations;

namespace OdataApplication.Controllers
{
    public class OverviewController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public class ExtendedDataManagerRequest : DataManagerRequest
        {  //inherit the class to show NewName as property of DataManager
            public string dataCount { get; set; }
        }

        [Route("api/UrlDataSource")]
        public IActionResult UrlDataSource([FromBody] ExtendedDataManagerRequest dm)
        {

            IQueryable<dynamic> DataSource;
            int count;
            // Overview drop down value change

            if (TradeDetails.tradeData.Count == 0)
            {
                TradeDetails.cacheDataCount = 1000;
                TradeDetails.GetAllRecords();
            }
            else if (int.TryParse(dm.dataCount, out int dataCount))
            {
                TradeDetails.cacheDataCount = dataCount;
            }
            DataSource = TradeDetails.tradeData.Take(TradeDetails.cacheDataCount).AsQueryable();

            var operation = new QueryableOperation();


            //if (dm.Select != null)
            //{
            //    IQueryable Data = operation.PerformSelect(DataSource.Cast<dynamic>(), dm.Select);  // Selected the columns value based on the filter request 
            //    DataSource = Data.Cast<dynamic>().Distinct().AsQueryable(); // Get the distinct values from the selected column 
            //}
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                //if (dm.Select != null)
                //{
                //    DataSource = operation.PerformFiltering(DataSource.Cast<dynamic>(), dm.Where, dm.Where[0].Operator);
                //}
                //else
                //{
                    DataSource = operation.PerformFiltering(DataSource.Cast<TradeDetails>(), dm.Where, dm.Where[0].Operator);
                //}
            }
            if (dm.Search != null && dm.Search.Count > 0)  //Search
            {
                //if (dm.Select != null)
                //{
                //    DataSource = operation.PerformSearching(DataSource.Cast<dynamic>(), dm.Search);
                //}
                //else
                //{
                    DataSource = operation.PerformSearching(DataSource.Cast<TradeDetails>(), dm.Search);
                //}
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                //if (dm.Select != null)
                //{
                //    DataSource = operation.PerformSorting(DataSource.Cast<dynamic>(), dm.Sorted);
                //}
                //else
                //{
                    DataSource = operation.PerformSorting(DataSource.Cast<TradeDetails>(), dm.Sorted);
                //}
            }
            if (dm.Select != null && DataSource.Cast<dynamic>().Count() != 0)
            {
                IQueryable Data = operation.PerformSelect(DataSource.Cast<dynamic>(), dm.Select);  // Selected the columns value based on the filter request 
                DataSource = Data.Cast<dynamic>().Distinct().AsQueryable(); // Get the distinct values from the selected column 
            }
            count = DataSource.Cast<dynamic>().Count();

            if (dm.Skip != 0)
            {
                if (dm.Select != null)
                {
                    DataSource = operation.PerformSkip(DataSource.Cast<dynamic>(), dm.Skip);//Paging
                }
                else
                {
                    DataSource = operation.PerformSkip(DataSource.Cast<TradeDetails>(), dm.Skip);//Paging
                }
            }
            if (dm.Take != 0)
            {
                if (dm.Select != null)
                {
                    DataSource = operation.PerformTake(DataSource.Cast<dynamic>(), dm.Take);
                }
                else
                {
                    DataSource = operation.PerformTake(DataSource.Cast<TradeDetails>(), dm.Take);
                }
            }

            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }
    }
    public class TradeDetails
    {
        public static List<TradeDetails> tradeData = new List<TradeDetails>();
        public static int cacheDataCount = new int();

        public TradeDetails()
        {

        }
        public TradeDetails(bool Check, int EmployeeID, string Employees, string Designation, string Location, string Status, string Trustworthiness, int Rating, int Software, string EmployeeImg, int CurrentSalary, string Address, string Mail, DateTime? Date)
        {
            this.Check = Check;
            this.EmployeeID = EmployeeID;
            this.Employees = Employees;
            this.Designation = Designation;
            this.Location = Location;
            this.Status = Status;
            this.Trustworthiness = Trustworthiness;
            this.Rating = Rating;
            this.Software = Software;
            this.EmployeeImg = EmployeeImg;
            this.CurrentSalary = CurrentSalary;
            this.Address = Address;
            this.Mail = Mail;
            this.Date = Date;
        }

        public static List<TradeDetails> GetAllRecords()
        {
            bool[] check = { true, false };
            string[] Employees = {
                        "Michael", "Kathryn", "Tamer", "Martin", "Davolio", "Nancy", "Fuller", "Leverling", "Peacock",
                        "Margaret", "Buchanan", "Janet", "Andrew", "Callahan", "Laura", "Dodsworth", "Anne",
                        "Bergs", "Vinet", "Anton", "Fleet", "Zachery", "Van", "King", "Jack", "Rose"
                };
            string[] Designation = { "Manager", "CFO", "Designer", "Developer", "Program Directory", "System Analyst", "Project Lead" };
            string[] Mail = { "sample.com", "arpy.com", "rpy.com", "mail.com", "jourrapide.com" };
            string[] category = { "Energy", "Financial", "Technology", "Industrial" };
            string[] Location = { "UK", "USA", "Sweden", "France", "Canada", "Argentina", "Austria", "Germany", "Mexico" };
            string[] Status = { "Active", "Inactive" };
            string[] Trustworthiness = { "Perfect", "Sufficient", "Insufficient" };

            string[] Address = { "59 rue de l\"Abbaye", "Luisenstr. 48", "Rua do Paço, 67", "2, rue du Commerce", "Boulestring[] d Tirou, 255",
                        "Rua do Paço, 67", "Hauptstr. 31", "Starenweg 5", "Rua do Mercado, 12", "Carrera 22 con Ave. Carlos Soublette #8-35", "Kirchgasse 6",
                        "Sierras de Granada 9993", "Mehrheimerstr. 369", "Rua da Panificadora, 12", "2817 Milton Dr.", "Kirchgasse 6", "Åkergatan 24", "24, place Kléber",
                        "Torikatu 38", "Berliner Platz 43", "5ª Ave. Los Palos Grandes", "1029 - 12th Ave. S.",
                        "Torikatu 38", "P.O. Box 555", "2817 Milton Dr.", "Taucherstraße 10", "59 rue de l\"Abbaye", "Via Ludovico il Moro 22",
                        "Avda. Azteca 123", "Heerstr. 22", "Berguvsvägen  8", "Magazinweg 7", "Berguvsvägen  8", "Gran Vía, 1", "Gran Vía, 1",
                        "Carrera 52 con Ave. Bolístring[] #65-98 Llano Largo", "Magazinweg 7", "Taucherstraße 10", "Taucherstraße 10",
                        "Av. Copacabana, 267", "Strada Provinciale 124", "Fauntleroy Circus", "Av. dos Lusíadas, 23",
                        "Rua da Panificadora, 12", "Av. Inês de Castro, 414", "Avda. Azteca 123", "2817 Milton Dr."};
            string[] EmployeeImg = { "usermale", "userfemale" };
            //Random random = new Random();

            int code = 10000;
            for (int i = 1; i <= 1000; i++)
            {
                tradeData.Add(new TradeDetails(check[0], code + 1, Employees[i % Employees.Length] + ' ' + Employees[(i + 5) % Employees.Length], Designation[2], Location[8], Status[0], Trustworthiness[1], 3, (i + 10) % 100, EmployeeImg[0], (i * 1612) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 98 + "@@" + Mail[4], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[1], code + 2, Employees[i % Employees.Length] + ' ' + Employees[(i + 4) % Employees.Length], Designation[0], Location[4], Status[1], Trustworthiness[0], 5, (i + 50) % 100, EmployeeImg[1], (i * 5321) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 10 + "@@" + Mail[1], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[1], code + 3, Employees[i % Employees.Length] + ' ' + Employees[(i + 2) % Employees.Length], Designation[6], Location[1], Status[1], Trustworthiness[2], 1, (i + 30) % 100, EmployeeImg[1], (i * 12756) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 58 + "@@" + Mail[3], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[0], code + 4, Employees[i % Employees.Length] + ' ' + Employees[(i + 3) % Employees.Length], Designation[3], Location[6], Status[0], Trustworthiness[0], 4, (i + 20) % 100, EmployeeImg[0], (i * 3298) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 31 + "@@" + Mail[0], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[1], code + 5, Employees[i % Employees.Length] + ' ' + Employees[(i + 1) % Employees.Length], Designation[5], Location[5], Status[1], Trustworthiness[0], 3, (i + 70) % 100, EmployeeImg[1], (i * 8418) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 87 + "@@" + Mail[1], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[0], code + 6, Employees[i % Employees.Length] + ' ' + Employees[(i + 3) % Employees.Length], Designation[1], Location[2], Status[0], Trustworthiness[1], 2, (i + 40) % 100, EmployeeImg[0], (i * 2617) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 23 + "@@" + Mail[3], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[0], code + 7, Employees[i % Employees.Length] + ' ' + Employees[(i + 5) % Employees.Length], Designation[1], Location[7], Status[0], Trustworthiness[2], 5, (i + 60) % 100, EmployeeImg[0], (i * 7492) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 49 + "@@" + Mail[2], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[0], code + 8, Employees[i % Employees.Length] + ' ' + Employees[(i + 2) % Employees.Length], Designation[4], Location[6], Status[0], Trustworthiness[0], 3, (i + 80) % 100, EmployeeImg[0], (i * 6319) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 62 + "@@" + Mail[4], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[1], code + 9, Employees[i % Employees.Length] + ' ' + Employees[(i + 1) % Employees.Length], Designation[0], Location[3], Status[1], Trustworthiness[2], 1, (i + 30) % 100, EmployeeImg[1], (i * 4519) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 18 + "@@" + Mail[2], new DateTime(1998, 10, 15).AddDays(i))); i++;
                tradeData.Add(new TradeDetails(check[1], code + 10, Employees[i % Employees.Length] + ' ' + Employees[(i + 4) % Employees.Length], Designation[3], Location[0], Status[1], Trustworthiness[2], 4, (i + 90) % 100, EmployeeImg[1], (i * 9618) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 07 + "@@" + Mail[0], new DateTime(1998, 10, 15).AddDays(i)));
                //tradeData.Add(new TradeDetails(check[1], code + 9, "", Designation[0], Location[3], Status[1], Trustworthiness[2], 1, (i + 30) % 100, EmployeeImg[1], (i * 4519) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 18 + "@@" + Mail[2], new DateTime(1998, 10, 15).AddDays(i))); i++;
                //tradeData.Add(new TradeDetails(check[1], code + 10, Employees[i % Employees.Length] + ' ' + Employees[(i + 4) % Employees.Length], Designation[3], Location[0], Status[1], Trustworthiness[2], 4, (i + 90) % 100, EmployeeImg[1], (i * 9618) % 100000, Address[i % Address.Length], Employees[i % Employees.Length].ToLower() + 07 + "@@" + Mail[0], null));// new DateTime(1998, 10, 15).AddDays(i)
                code += 10;
            }
            return tradeData;
        }

        [Key]

        public bool Check { get; set; }
        public int EmployeeID { get; set; }
        public string Employees { get; set; }
        public string Designation { get; set; }
        public string Location { get; set; }
        public string Status { get; set; }
        public string Trustworthiness { get; set; }
        public int Rating { get; set; }
        public int Software { get; set; }
        public string EmployeeImg { get; set; }
        public int CurrentSalary { get; set; }
        public string Address { get; set; }
        public string Mail { get; set; }
        public DateTime? Date { get; set; }
    }
}
