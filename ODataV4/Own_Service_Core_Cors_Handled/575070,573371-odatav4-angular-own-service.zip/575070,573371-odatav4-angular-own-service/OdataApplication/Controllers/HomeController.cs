﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Newtonsoft.Json;
using OdataApplication.Models;
using System.Diagnostics;
using static OdataApplication.Controllers.OverviewController;

namespace OdataApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult TestFetch()
        {
            return View();
        }
        [Route("api/Test")]
        public IActionResult Test([FromBody] DataManagerRequest dm) {

            return View();
        }

        public class DataManagerRequest
        {
            [HtmlAttributeName("skip")]
            [JsonProperty("skip")]
            public int Skip { get; set; }

            [HtmlAttributeName("take")]
            [JsonProperty("take")]
            public int Take { get; set; }

            [HtmlAttributeName("requiresCounts")]
            [JsonProperty("requiresCounts")]
            public bool RequiresCounts { get; set; }

            [HtmlAttributeName("select")]
            [JsonProperty("select")]
            public List<string> Select { get; set; }

            [HtmlAttributeName("sorted")]
            [JsonProperty("sorted")]
            public List<Sort> Sorted { get; set; }

            [HtmlAttributeName("where")]
            [JsonProperty("where")]
            public List<WhereFilter> Where { get; set; }

            [HtmlAttributeName("isLazyLoad")]
            [JsonProperty("isLazyLoad")]
            public bool IsLazyLoad { get; set; }
        }

        public class WhereFilter
        {
            public string Field { get; set; }
            public Boolean IgnoreCase { get; set; }
            public Boolean IsComplex { get; set; }
            public string Operator { get; set; }
            public string Condition { get; set; }
            public object value { get; set; }
            public List<WhereFilter> predicates { get; set; }
        }

        public class Sort
        {
            public string Name { get; set; }
            public string Direction { get; set; }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}