﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;
using OdataApplication.Models;
using Syncfusion.EJ2.Base;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace OdataApplication.Controllers
{
    public class HomeController : Controller
    {
        public static List<OrdersDetails> orddata = OrdersDetails.GetAllRecords();
        public static List<OrdersDetails> orddata1 = OrdersDetails.GetAllRecords().Take(2).ToList();
        public IActionResult Index()
        {
            ViewBag.datasource = OrdersDetails.GetAllRecords();
            ViewBag.datasource1 = OrdersDetails.GetAllRecords().Take(2);
            return View();
        }

        public IActionResult UrlDatasource([FromBody] DataManagerRequest dm)
        {

            IEnumerable DataSource = orddata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        public IActionResult Update([FromBody] CRUDModel<OrdersDetails> myObject)
        {
            var ord = myObject;
            OrdersDetails val = orddata.Where(or => or.OrderID == ord.Value.OrderID).FirstOrDefault();
            if (val != null)
            {
                val.OrderID = ord.Value.OrderID;
                val.EmployeeID = ord.Value.EmployeeID;
                val.CustomerID = ord.Value.CustomerID;
                val.Freight = ord.Value.Freight;
                val.OrderDate = ord.Value.OrderDate;
                val.ShipCity = ord.Value.ShipCity;
                val.ShipAddress = ord.Value.ShipAddress;
                val.ShippedDate = ord.Value.ShippedDate;
            }

            return Json(ord.Value);

        }
        public IActionResult Insert([FromBody] CRUDModel<OrdersDetails> value)
        {
            var ord = value;
            orddata.Insert(0, ord.Value);
            return Json(value.Value);
        }
        public IActionResult Delete([FromBody] CRUDModel<OrdersDetails> value)
        {
            int key;
            if (int.TryParse(value.Key.ToString(), out key))
            {
                orddata.Remove(orddata.Where(or => or.OrderID == key).FirstOrDefault());
            }
            return Json(value);
        }

        public class RowDrop
        {
            public RowDrop()
            {

            }

            [Key]
            [JsonProperty("data")]
            public List<OrdersDetails> data { get; set; }
            [JsonProperty("dropIndex")]
            public int dropIndex { get; set; }
        }

        public IActionResult RowDropped([FromBody] RowDrop value)
        {
            //update db here
            for (int i = 0; i < value.data.Count; i++)
            {
                orddata.Remove(orddata.Where(or => or.OrderID == value.data[i].OrderID).FirstOrDefault());
                orddata.Insert(value.dropIndex, value.data[i]);
            }
            return Json(new { data1 = orddata });
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult TestFetch()
        {
            return View();
        }

    }
    [Route("api/[controller]")]
    public class OrderController: Controller
    {
        // GET: api/Orders
        [HttpGet]

        public object Get()
        {
            var queryString = Request.Query;
            var data = OrdersDetails.GetAllRecords().ToList();
            int skip = Convert.ToInt32(queryString["$skip"]);
            int take = Convert.ToInt32(queryString["$top"]);
            string sort = queryString["$orderby"];   // get the sort queries 
            string filter = queryString["$filter"];  //filtering
            if (filter != null) // to handle filter opertaion
            {
                if (filter.Contains("substring"))//searching 
                {

                    var key = filter.Split(new string[] { "'" }, StringSplitOptions.None)[1];
                    data = data.Where(fil => fil.ShipCountry.ToLower().ToString().Contains(key.ToLower())
                                            || fil.ShipName.ToLower().ToString().Contains(key.ToLower())
                                            || fil.Freight.ToString().Contains(key.ToLower())
                                            || fil.CustomerID.ToLower().ToString().Contains(key.ToLower())
                                            || fil.EmployeeID.ToString().Contains(key)
                                            || fil.ShipCity.ToLower().Contains(key.ToLower())
                                            || fil.OrderID.ToString().Contains(key)).ToList();
                }
                else
                {
                    var newfiltersplits = filter;
                    var filtersplits = newfiltersplits.Split('(', ')', ' ');
                    var filterfield = filtersplits[1];
                    var filtervalue = filtersplits[3];

                    if (filtersplits.Length == 5)
                    {
                        if (filtersplits[1] == "tolower")
                        {
                            filterfield = filter.Split('(', ')', '\'')[2];
                            filtervalue = filter.Split('(', ')', '\'')[4];
                        }
                    }
                    if (filtersplits.Length != 5)
                    {
                        filterfield = filter.Split('(', ')', '\'')[3];
                        filtervalue = filter.Split('(', ')', '\'')[5];

                    }

                    if (filterfield == "OrderID")
                    {
                        data = (from cust in data
                                where cust.OrderID.ToString() == filtervalue.ToString()
                                select cust).ToList();
                    }
                    if (filterfield == "Freight")
                    {
                        data = (from cust in data
                                where cust.OrderID.ToString() == filtervalue.ToString()
                                select cust).ToList();
                    }
                    if (filterfield == "EmployeeID")
                    {
                        data = (from cust in data
                                where cust.EmployeeID.ToString() == filtervalue.ToString()
                                select cust).ToList();
                    }
                    if (filterfield == "Verified")
                    {
                        data = (from cust in data
                                where cust.Verified.ToString() == filtervalue.ToString()
                                select cust).ToList();
                    }

                    if (filterfield == "CustomerID")
                    {
                        data = (from cust in data
                                where cust.CustomerID.ToLower().StartsWith(filtervalue.ToString())
                                select cust).ToList();
                    }
                    if (filterfield == "ShipCity")
                    {
                        data = (from cust in data
                                where cust.ShipCity.ToLower().StartsWith(filtervalue.ToString())
                                select cust).ToList();
                    }
                    if (filterfield == "ShipCountry")
                    {
                        data = (from cust in data
                                where cust.ShipCountry.ToLower().StartsWith(filtervalue.ToString())
                                select cust).ToList();
                    }
                    if (filterfield == "ShipName")
                    {
                        data = (from cust in data
                                where cust.ShipName.ToLower().StartsWith(filtervalue.ToString())
                                select cust).ToList();
                    }
                    if (filterfield == "OrderDate")
                    {
                        data = (from cust in data
                                where cust.OrderDate.ToString() == filtervalue.ToString()
                                select cust).ToList();
                    }
                }
            }
            if (sort != null) //Sorting 
            {
                var multiSort = sort.Split(',');
                for (int i = 0; i < multiSort.Length; i++)
                {
                    switch (multiSort[i])
                    {
                        case "OrderID":
                            data = data.OrderBy(x => x.OrderID).ToList();
                            break;
                        case "OrderID desc":
                            data = data.OrderByDescending(x => x.OrderID).ToList();
                            break;
                        case "EmployeeID":
                            data = data.OrderBy(x => x.EmployeeID).ToList();
                            break;
                        case "EmployeeID desc":
                            data = data.OrderByDescending(x => x.EmployeeID).ToList();
                            break;
                        case "CustomerID":
                            data = data.OrderBy(x => x.CustomerID).ToList();
                            break;
                        case "CustomerID desc":
                            data = data.OrderByDescending(x => x.CustomerID).ToList();
                            break;
                        case "ShipCity":
                            data = data.OrderBy(x => x.ShipCity).ToList();
                            break;
                        case "ShipCity desc":
                            data = data.OrderByDescending(x => x.ShipCity).ToList();
                            break;
                        case "ShipCountry":
                            data = data.OrderBy(x => x.ShipCountry).ToList();
                            break;
                        case "ShipCountry desc":
                            data = data.OrderByDescending(x => x.ShipCountry).ToList();
                            break;
                        case "Freight":
                            data = data.OrderBy(x => x.ShipCountry).ToList();
                            break;
                        case "Freight desc":
                            data = data.OrderByDescending(x => x.Freight).ToList();
                            break;
                        case "ShipName":
                            data = data.OrderBy(x => x.ShipCountry).ToList();
                            break;
                        case "ShipName desc":
                            data = data.OrderByDescending(x => x.ShipName).ToList();
                            break;
                    }
                }
                
            }
            return take != 0 ? new { Items = data.Skip(skip).Take(take).ToList(), Count = data.Count() } : new { Items = data, Count = data.Count() };
        }


        // GET: api/Orders/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Orders
        [HttpPost]
        public object Post([FromBody] OrdersDetails value)
        {
            OrdersDetails.GetAllRecords().Insert(0, value);
            var data = OrdersDetails.GetAllRecords().ToList();
            return Json(new { result = data, count = data.Count });
        }


        // PUT: api/Orders/5
        [HttpPut]
        public object Put(int id, [FromBody] OrdersDetails value)
        {


            var ord = value;
            OrdersDetails val = OrdersDetails.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
            val.OrderID = ord.OrderID;
            val.EmployeeID = ord.EmployeeID;
            val.CustomerID = ord.CustomerID;
            val.Freight = ord.Freight;
            val.OrderDate = ord.OrderDate;
            val.ShipCity = ord.ShipCity;
            val.ShipCountry = ord.ShipCountry;
            val.Verified = ord.Verified;
            return value;
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id:int}")]
        [Route("Orders/{id:int}")]
        public object Delete(int id)
        {
            OrdersDetails.GetAllRecords().Remove(OrdersDetails.GetAllRecords().Where(or => or.OrderID == id).FirstOrDefault());
            return Json(id);
        }
    }
}